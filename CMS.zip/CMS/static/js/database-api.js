// Database API helper for the Case Management System.
// Include this file in your frontend pages and use these functions from form handlers.

async function apiRequest(url, method = 'GET', data = null) {
  const options = { method, headers: { 'Content-Type': 'application/json' } };
  if (data !== null) options.body = JSON.stringify(data);
  const response = await fetch(url, options);
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Request failed');
  return result;
}

const CaseAPI = {
  list: () => apiRequest('/api/cases'),
  create: (data) => apiRequest('/api/cases', 'POST', data),
  get: (id) => apiRequest(`/api/cases/${id}`),
  update: (id, data) => apiRequest(`/api/cases/${id}`, 'PUT', data),
  remove: (id) => apiRequest(`/api/cases/${id}`, 'DELETE')
};

const AgencyAPI = {
  list: () => apiRequest('/api/agencies'),
  create: (data) => apiRequest('/api/agencies', 'POST', data),
  remove: (id) => apiRequest(`/api/agencies/${id}`, 'DELETE')
};

const CollaborationAPI = {
  list: () => apiRequest('/api/collaborations'),
  create: (data) => apiRequest('/api/collaborations', 'POST', data),
  update: (id, data) => apiRequest(`/api/collaborations/${id}`, 'PUT', data),
  remove: (id) => apiRequest(`/api/collaborations/${id}`, 'DELETE')
};

const DashboardAPI = {
  get: () => apiRequest('/api/dashboard')
};
